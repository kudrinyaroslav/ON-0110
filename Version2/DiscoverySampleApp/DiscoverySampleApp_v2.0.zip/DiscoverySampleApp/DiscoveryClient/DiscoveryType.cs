﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ONVIFSampleApp
{
    class DiscoveryType
    {
        public string Type { get; set; }
        public string Namespace { get; set; }
    }

}
